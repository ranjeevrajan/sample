<?php

class Offi_CustomerAttribute_Model_Attributemetada extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('customerattribute/attributemetada');
    }
}